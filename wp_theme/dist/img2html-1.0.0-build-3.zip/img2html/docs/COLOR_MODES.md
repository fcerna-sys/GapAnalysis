# Modos de color

Define variaciones claro/oscuro/alto contraste y mantiene contraste AA/AAA.
# CPT

CPT sugeridos: `portfolio`, `testimonials`. Plantillas: `single-portfolio.html`, `archive-portfolio.html`.
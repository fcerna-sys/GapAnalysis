# Taxonomías

Taxonomías sugeridas: `project-type`, `client`. Archivo: `templates/archive-project-type.html`.
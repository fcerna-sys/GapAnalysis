# Changelog - img2html

Todas las actualizaciones notables de este tema se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/).


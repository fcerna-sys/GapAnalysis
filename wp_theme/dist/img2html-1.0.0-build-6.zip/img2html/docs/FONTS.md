# Fuentes

Declara fuentes con Webfonts API y mapea familias/tamaños en `theme.json`.
Gradientes: presets y uso.

Aplicar en Cover y Buttons.
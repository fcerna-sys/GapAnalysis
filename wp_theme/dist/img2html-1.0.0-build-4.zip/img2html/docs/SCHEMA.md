Schema: JSON‑LD para sitio y artículos.

Uso: hook en `wp_head`.
# Documentación de Patterns

Documentación completa de todos los patterns del tema `img2html`.

## 📚 Índice

### Patterns Sincronizados

Estos patterns se actualizan globalmente:


### Patterns Reutilizables

Estos patterns se pueden insertar múltiples veces:


---

*Documentación generada automáticamente*

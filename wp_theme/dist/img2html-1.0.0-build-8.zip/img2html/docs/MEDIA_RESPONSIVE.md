Imágenes responsivas: tamaños, `srcset` y `sizes`.

Galerías: lightbox desde bloque core/gallery.
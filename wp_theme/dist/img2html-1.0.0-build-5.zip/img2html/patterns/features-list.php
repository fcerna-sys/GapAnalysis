<?php
/*
Title: Lista de características
Description: Sección con lista de beneficios
Categories: img2html-cards
Sync Status: synced
*/
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
<!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="has-text-align-center">Características</h2>
<!-- /wp:heading -->
<!-- wp:img2html/molecule-features-list {"title":"Beneficios","items":["Rápido","Seguro","Escalable"]} /-->
</div>
<!-- /wp:group -->

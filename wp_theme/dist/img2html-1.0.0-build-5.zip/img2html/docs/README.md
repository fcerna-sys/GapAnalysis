# Img2HTML Theme Runtime

Configura modelos locales/remotos en `prompts/runtime.json` y ejecuta `prompts/runner.py` para materializar plantillas, parts, patrones y fusionar estilos.
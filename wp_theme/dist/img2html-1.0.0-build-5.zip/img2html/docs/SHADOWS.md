Sombras: librería de presets.

Usar en botones, tarjetas y modales.
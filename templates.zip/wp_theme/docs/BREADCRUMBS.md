Breadcrumbs: patrón accesible.

ARIA y separadores adecuados.
# Ajustes de media

Activa lightbox en Galería y ajusta resolución en Imagen y Cover.
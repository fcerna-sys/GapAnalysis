<?php
/*
Title: Hero (Bloque Organismo)
Description: Hero basado en el bloque img2html/organism-hero
Categories: img2html-hero
Sync Status: synced
*/
?>
<!-- wp:img2html/organism-hero {"title":"Título destacado","subtitle":"Subtítulo breve que explica el valor","buttonText":"Empezar","buttonUrl":"#"} /-->

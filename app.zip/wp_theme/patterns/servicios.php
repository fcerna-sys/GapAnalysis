<?php
/**
 * Title: Servicios
 * Slug: img2html/servicios
 * Description: Sección de servicios con tarjetas
 * Categories: img2html-cards, services
 * Keywords: servicios, grid, tarjetas
 * Viewport Width: 1200
 * Block Types: core/post-content
 * Inserter: yes
 * Sync Status: synced
 */
?>
<!-- wp:img2html/cards-grid {"title":"Nuestros Servicios","columns":3} -->
<!-- wp:img2html/card {"title":"Consultoría","text":"Análisis y estrategia para tu producto.","buttonText":"Ver más","buttonUrl":"#"} /-->
<!-- wp:img2html/card {"title":"Diseño","text":"UI/UX enfocado en conversión.","buttonText":"Ver más","buttonUrl":"#"} /-->
<!-- wp:img2html/card {"title":"Desarrollo","text":"Frontend y backend escalable.","buttonText":"Ver más","buttonUrl":"#"} /-->
<!-- /wp:img2html/cards-grid -->

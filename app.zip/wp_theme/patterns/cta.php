<?php
/**
 * Title: CTA Global
 * Slug: img2html/cta
 * Description: Llamada a la acción reutilizable con botones
 * Categories: img2html-call-to-action, call-to-action
 * Keywords: cta, llamado, acción
 * Viewport Width: 1200
 * Block Types: core/post-content
 * Inserter: yes
 * Sync Status: synced
 */
?>
<!-- wp:img2html/cta {"title":"¿Listo para empezar?","text":"Únete hoy y mejora tu proyecto.","primaryButtonText":"Comenzar","primaryButtonUrl":"#","secondaryButtonText":"Saber más","secondaryButtonUrl":"#","showSecondaryButton":true,"alignment":"center","backgroundStyle":"primary"} /-->

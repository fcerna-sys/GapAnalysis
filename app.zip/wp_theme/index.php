<?php
/**
 * Silence is golden.
 */






<?php
/**
 * Silence is golden.
 */




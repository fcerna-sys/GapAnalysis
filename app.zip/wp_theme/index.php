<?php
/**
 * Silence is golden.
 */







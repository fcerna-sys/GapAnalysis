Atajos del editor: lista y buenas prácticas.

Bloques: inserción rápida, duplicar, agrupar.
Patrones: bloqueo y sincronización.
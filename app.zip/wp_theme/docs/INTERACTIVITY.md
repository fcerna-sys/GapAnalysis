# Interactivity API

Usa `wp-each` y `data-wp-bind--style` para listas y estilos sin inline.
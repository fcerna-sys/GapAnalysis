Duotone: filtros de imagen.

Aplicar a bloques Image y Gallery.
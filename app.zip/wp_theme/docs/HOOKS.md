# Block Hooks

Inserta bloques en contenido y patrones sincronizados según WordPress 6.8.
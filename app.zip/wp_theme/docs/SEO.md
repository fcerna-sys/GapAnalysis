# SEO básico

Usa jerarquía correcta de headings y textos de enlace descriptivos en plantillas.
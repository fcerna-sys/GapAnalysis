# Experiencia del editor

Habilita `appearanceTools` y define presets coherentes en `theme.json`.
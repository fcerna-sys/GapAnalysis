# Patrones

Los patrones se organizan en `wp_theme/patterns/` y se registran bajo la categoría Img2HTML.
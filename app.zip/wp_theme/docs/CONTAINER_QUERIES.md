Container Queries: uso y prácticas.

Configurar bloques con clases contenedoras.
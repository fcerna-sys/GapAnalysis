WooCommerce: soporte básico del tema.

Estilos: usar presets de `theme.json`.
Plantillas: páginas de tienda y producto via bloques Woo.